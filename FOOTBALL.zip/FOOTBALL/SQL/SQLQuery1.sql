create database players
use players 

select 
*from [dbo].[finalized_data_in_csv]